package com.masaischool.dao;

import java.util.List;

import com.masaischool.dto.Employee;
import com.masaischool.exception.Somehingwentrong;

public interface EmployeeDAO {
	
	public void addEmployee(Employee employee) throws Somehingwentrong;
	public List<Employee> viewAllEmployee() throws Somehingwentrong;
	public void updateEmployee(Employee employee) throws Somehingwentrong;
	public void deleteEmployee(int t) throws Somehingwentrong;
	public Employee viewSingleEmployee(int id) throws Somehingwentrong;
	public void borrowAmount(int landerid,int borrowid,double amountInLpa) throws Somehingwentrong;
}
