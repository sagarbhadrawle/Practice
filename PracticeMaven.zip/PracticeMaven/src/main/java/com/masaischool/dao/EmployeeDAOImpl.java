package com.masaischool.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.List;

import com.masaischool.dto.Employee;
import com.masaischool.exception.Somehingwentrong;
import com.masaischool.utility.DBUtils;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public void addEmployee(Employee employee) throws Somehingwentrong {
		// TODO Auto-generated method stub
		
			Connection conn=null;
		try{
			
			conn =  DBUtils.createConnection();
			//you are here means connection is successful
			//Create Query
			String insertQuery = "INSERT INTO employee (name, salary, state, joining_date) VALUES (?, ?, ?, ?)";
			//Create a PreparedStatement
			PreparedStatement ps = conn.prepareStatement(insertQuery);
			//stuff the data
			ps.setString(1, employee.getName());
			ps.setDouble(2, employee.getSalary());
			ps.setString(3, employee.getState());
			ps.setDate(4, Date.valueOf(employee.getDate()));
			
			//DML statement so executeUpdate
			ps.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new Somehingwentrong(e.getMessage());
//			throw  new Somehing?wentrong("Inserted succesfully");
			
		}finally {
			try {
				DBUtils.closeConnection(conn);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new Somehingwentrong(e.getMessage());
			}
			
		}
		
		
		
	}

	@Override
	public List<Employee> viewAllEmployee() throws Somehingwentrong {
		
		List<Employee> em = null;
		Connection con = null;
		try { 
			con = DBUtils.createConnection();
			String insertquery = "SELECT * FROM employee";
			PreparedStatement ps =   con.prepareStatement(insertquery);
			
			ResultSet rs  = ps.executeQuery();
	
				if(DBUtils.isResultSetEmpty(rs))
				{
					throw new Somehingwentrong("no detail found");
				}
			em = new ArrayList<>();	
			while(rs.next())
			{
				em.add(new Employee( rs.getInt(1),rs.getString(2), rs.getDouble(3),rs.getString(4), rs.getDate(5).toLocalDate() ));
				
			}
			
		} catch (SQLException e) {
			throw new Somehingwentrong(e.getMessage());
		}
		finally {
			
			try {
				
				DBUtils.closeConnection(con);
			}
			catch(SQLException ex )
			{
				throw new Somehingwentrong(ex.getMessage());
			}
			
		}
		
		return em;
			
			
		
			
			
			
	}

	@Override
	public void updateEmployee(Employee employee) throws Somehingwentrong {
		
		Connection con = null;
		try {
			con = DBUtils.createConnection();
			
			String updatequery = "UPDATE employee  set name=?,salary=?,state=?,joining_date=? where id=?";
			
			PreparedStatement ps = con.prepareStatement(updatequery);
			
			ps.setString(1, employee.getName());
			ps.setDouble(2, employee.getSalary());
			ps.setString(3,employee.getState());
			ps.setDate(4, Date.valueOf(employee.getDate()));
			ps.setInt(5, employee.getId());
			
			
			int row =ps.executeUpdate();
			if(row==0)
			{
				throw new Somehingwentrong("details is not updated"); 
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO: handle exception
			throw new Somehingwentrong(e.getMessage());
		}
		
	}

	@Override
	public void deleteEmployee(int t) throws Somehingwentrong {
		
		Connection con = null;
		try {
			con = DBUtils.createConnection();
			String query = "Delete FROM employee where id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, t);
			
			int row = ps.executeUpdate();
			if(row ==0)
			{
				throw new Somehingwentrong("data is not deleted");
			}
			System.out.println("delete successfully");
			
			
			
		} catch (SQLException e) {
				
			throw new Somehingwentrong(e.getMessage());
		}
			
	}

	@Override
	public Employee viewSingleEmployee(int id) throws Somehingwentrong {
			
		Connection con =null;
		try {
			con = DBUtils.createConnection();
			String query = "SELECT * from employee where id =?";
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			 
			if(DBUtils.isResultSetEmpty(rs)) {
				throw new Somehingwentrong("No result");
			}
			rs.next();
			Employee em = new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getString(4),rs.getDate(5).toLocalDate());
			
			return em;
			
			
			
			
			
		} catch (SQLException e) {
			throw new Somehingwentrong(e.getMessage());
		}
		
				
		
	}

	@Override
	public void borrowAmount(int landerid, int borrowid, double amountInLpa) throws Somehingwentrong {
		
		Connection con =null;
		Savepoint insertp =null;	
		try {                                                                                                                                                                                                                                                                                                                                            
			con = DBUtils.createConnection();
			
			String selectQuery = "SELECT COUNT(*) FROM EMPLOYEE WHERE id =? OR id =?";
			PreparedStatement p = con.prepareStatement(selectQuery);
			p.setInt(1, landerid);
			p.setInt(2, borrowid);
			ResultSet rs = p.executeQuery();
			rs.next();
			if(rs.getInt(1)<2)
			{	
				
				throw new Somehingwentrong("enter correct id");
			}
			
			
			con.setAutoCommit(false);
			String query = "UPDATE EMPLOYEE SET SALARY= SALARY-? WHERE id = ?";
			
			PreparedStatement ps = con.prepareStatement(query); 
			ps.setDouble(1, amountInLpa);
			ps.setInt(2, landerid);
			
			ps.executeUpdate();
			
			insertp = con.setSavepoint("landered reduct");
			
			String insertq = "update employee set salary= salary+?where id =?";
			PreparedStatement ps1 = con.prepareStatement(insertq);
			ps1.setDouble(1, amountInLpa);
			ps1.setInt(2, borrowid);
			
			ps1.executeUpdate();
			con.commit();
			
			
		} catch (SQLException e) {
			
			try {
				con.rollback(insertp);
				con.commit();
				System.out.println("rollback successfully");
				
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				throw new Somehingwentrong("details is not rollback");
			}
			finally {
				try {
					DBUtils.closeConnection(con);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		
	}
	
	
 
	
}
