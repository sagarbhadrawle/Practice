package com.masaischool.exception;

public class Somehingwentrong extends Exception {
	
	 public Somehingwentrong(String msg) {
		// TODO Auto-generated constructor stub
		 super(msg);
	}
}
