package com.masaischool.service;

import java.util.List;

import com.masaischool.dao.EmployeeDAO;
import com.masaischool.dao.EmployeeDAOImpl;
import com.masaischool.dto.Employee;
import com.masaischool.exception.Somehingwentrong;

public class EmployeeServiceImpl  implements EmployeeService{

	@Override
	public void addEmployee(Employee employee) throws  Somehingwentrong{
		
		EmployeeDAO dao = new EmployeeDAOImpl();
		dao.addEmployee(employee);
		
	}

	@Override
	public List<Employee> viewAllEmployee() throws Somehingwentrong {
		EmployeeDAO dao = new EmployeeDAOImpl();
		 return dao.viewAllEmployee(); 
		
	}

	@Override
	public void updateEmployee(Employee employee) throws Somehingwentrong {
		EmployeeDAO dao = new EmployeeDAOImpl();
		dao.updateEmployee(employee);
		
	}

	@Override
	public void deleteEmployee(int t) throws Somehingwentrong {
		EmployeeDAO dao = new EmployeeDAOImpl();
		dao.deleteEmployee(t);
		
	}

	@Override
	public Employee viewSingleEmployee(int id) throws Somehingwentrong {
		EmployeeDAO dao = new EmployeeDAOImpl();
		return	dao.viewSingleEmployee(id);
		 
	}

	@Override
	public List<Employee> getEmployeeyEmpIdDESC(List<Employee> empLis) {
		// TODO Auto-generated method stub
		return empLis.stream().sorted((e1,e2)->e2.getId()-e1.getId()).toList();
	}
   
	@Override
	public List<Employee> getEmployeeyByEmpName(List<Employee> empList) { 
		
		return empList.stream().sorted((e1,e2)->e1.getName().compareTo(e2.getName())).toList();
	}

	@Override
	public List<Employee> getEmployeeyByJoiningDateASC(List<Employee> empList) {
		
		return empList.stream().sorted((e1,e2)->e1.getDate().compareTo(e2.getDate())).toList();
	}

	@Override
	public void borrowAmount(int landerid, int borrowid, double amountInLpa) throws Somehingwentrong {
		EmployeeDAO dao = new EmployeeDAOImpl();
			dao.borrowAmount(landerid,borrowid,amountInLpa); 
		
	}
	
 
}
