package com.masaischool.service;

import java.util.List;
import java.util.Scanner;

import com.masaischool.dto.Employee;
import com.masaischool.exception.Somehingwentrong;

public interface EmployeeService {

	public void addEmployee(Employee employee) throws Somehingwentrong ;
	public List<Employee> viewAllEmployee() throws Somehingwentrong;
	public void updateEmployee(Employee employee) throws Somehingwentrong;
	public void deleteEmployee(int t) throws Somehingwentrong;
	public Employee viewSingleEmployee(int id) throws Somehingwentrong;
	List<Employee> getEmployeeyEmpIdDESC(List<Employee> empLis);
	List<Employee> getEmployeeyByEmpName(List<Employee> empList);
	List<Employee> getEmployeeyByJoiningDateASC(List<Employee> empList);
	public void borrowAmount(int landerid,int borrowid,double amountInLpa) throws Somehingwentrong;
	
	
	 
	
} 
  