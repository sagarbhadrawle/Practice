package com.masaischool.ui;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.masaischool.dao.EmployeeDAO;
import com.masaischool.dao.EmployeeDAOImpl;
import com.masaischool.dto.Employee;
import com.masaischool.exception.Somehingwentrong;
import com.masaischool.service.EmployeeService;
import com.masaischool.service.EmployeeServiceImpl;

public class UIMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int choice;
		do {
		System.out.println("1, Add employee");
		System.out.println("2, view all  employee");
		System.out.println("3, update employee");
		System.out.println("4,  delete employee");
		System.out.println("5, search employee");
		System.out.println("6, borrow amoout");
		System.out.println("0, exit ");
		
		choice = sc.nextInt();
		switch(choice) {	
		case 1:
			addEmployee(sc);
			break;
		case 2 :
			viewAllEmployee(sc);
			break;
		case 3:
			updateEmployee(sc);
			break;
		case 4: 
			deleteEmployee(sc);
			break;
		case 5:
			viewSingleEmployee(sc);
			break;
		case 6:
			borrowAmount(sc);
			break;
		case 0:
			System.out.println("thanks for using our service");
			break;
		default:
			System.out.println("invalid input");
		}
		}while(choice!=0);
		sc.close();
	}			

	
		static void borrowAmount(Scanner sc) 
		{
			System.out.println("Enter borrowed Amount");
			int amount = sc.nextInt();
			System.out.println("landered id");
			int landeredid= sc.nextInt();
			System.out.println("borrow id");
			int borrowid= sc.nextInt();
			
			
			
			
			EmployeeService es = new EmployeeServiceImpl();
			
			try {
				es.borrowAmount(landeredid, borrowid, amount);
				System.out.println("details updated successfully");
			} catch (Somehingwentrong e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}	
			
			
			
		}
	
	
	

		static void addEmployee(Scanner sc) {
		//code to take input Employee details //name, salary, state, joining_date
		System.out.println("Please enter name ");
		String name = sc.next();
		System.out.println("Please enter salary ");
		double salary =sc.nextDouble();
		System.out.println("Please enter state ");
		String state = sc.next();
		System.out.println("Please enter joining date (YYYY-MM-DD)");
		LocalDate joiningDate =LocalDate.parse(sc.next());
		
		Employee employee = new Employee(name,salary,state,joiningDate);
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		 
		EmployeeService es = new EmployeeServiceImpl();
		
		try {
			es.addEmployee(employee);
			System.out.println("INformation added succesfully");
		} catch (Somehingwentrong e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
			
		
		/**
		 * @param sc
		 */
		static void viewAllEmployee(Scanner sc)
		{
			
			EmployeeService es = new EmployeeServiceImpl();
			
			try {
				List<Employee> em = es.viewAllEmployee();
				
				
				int choice=0;
				do {
					System.out.println("1. See in the order of EmpId DESC");
					System.out.println("2. See in the order of EmpName ASC");
					System.out.println("3. See in the order of JoingDate ASC");
					System.out.println("0. Return");
					choice = sc.nextInt();
					switch(choice)
					{
					case 1 :
						es.getEmployeeyEmpIdDESC(em).stream().forEach(System.out::println); 
					break;
					case 2:
						es.getEmployeeyByEmpName(em).stream().forEach(System.out::println);
					break;
					case 3:
						es.getEmployeeyByJoiningDateASC(em).stream().forEach(System.out::println);
					break;
					case 0:
						System.out.println("thankyou using for");
						break;
					default:
						System.out.println("thankyou ");
					}
					
				}while(choice!=0);
					
					
					
//				for(Employee employee : em)
//				{	System.out.println("id: " + employee.getId());
//					 System.out.println("Name: " + employee.getName());
//			            System.out.println("Salary: " + employee.getSalary());
//			            System.out.println("State: " + employee.getState());
//			            System.out.println("Joining Date: " + employee.getDate());
//			            System.out.println("----------------------");
//				}
				
			} catch (Somehingwentrong e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} 
			
			
			
			
		}  
		
		
		static void updateEmployee(Scanner sc)
		{	
			System.out.println("enter the emp id");
			int id =  	Integer.parseInt(sc.next());
			System.out.print("Enter Employee Name: ");
			sc.nextLine();
			String name = sc.nextLine();
			System.out.print("Enter Employe Salary: ");
			Double salary = Double.parseDouble(sc.nextLine());
			System.out.print("Enter Employe state: ");
			String state = sc.nextLine();
			System.out.print("Enter Employe date: ");
			LocalDate date = LocalDate.parse(sc.nextLine());
			
			
			Employee em = new Employee(id, name, salary, state, date);
			
			EmployeeDAO ed = new EmployeeDAOImpl();
			try {
				ed.updateEmployee(em);
				System.out.println("details update succesfully");
			} catch (Somehingwentrong e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} 
			
		}
			
		
		static void deleteEmployee(Scanner sc)
		{
			System.out.println("enter emp id");
			int del = sc.nextInt();
			
			EmployeeDAO ed = new EmployeeDAOImpl();
			 try {
				ed.deleteEmployee(del);
			} catch (Somehingwentrong e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
			
			
		static void viewSingleEmployee(Scanner sc)
		{
			System.out.println("Enter employee id");
			int id = sc.nextInt();
			EmployeeDAO ed = new EmployeeDAOImpl();
			try {
				Employee e = ed.viewSingleEmployee(id);
				System.out.println(e.toString());
			} catch (Somehingwentrong e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
				
		}
	
	
}
	